## ********************FAILED********************

****************************************
## ********************SUCCESS********************
#### *****timeout 60 ./Arraylist/arraylist.bin --verbose*****
 ```Test Test 0:
  Case Add:1-5:
    main.c:90: Check !strcmp(vec->output, output)... ok
  SUCCESS: All conditions have passed.

Test Test 1:
  Case Add:1-3,Insert:100:0-3:
    main.c:127: Check !strcmp(vec->output, output)... ok
  SUCCESS: All conditions have passed.

Test Test 2:
  Case Add:1-5,Insert:100:0-6,Free:
    main.c:60: Check !strcmp(vec->output, output)... ok
  SUCCESS: All conditions have passed.

Summary:
  Count of all unit tests:        3
  Count of run unit tests:        3
  Count of failed unit tests:     0
  Count of skipped unit tests:    0
SUCCESS: All unit tests have passed.


```
#### *****timeout 60 ./word-count/test_strcmp.bin --verbose*****
 ```Test Test:
  test_strcmp.c:24: Check result == test_vectors[i].expected... ok
  test_strcmp.c:24: Check result == test_vectors[i].expected... ok
  test_strcmp.c:24: Check result == test_vectors[i].expected... ok
  test_strcmp.c:24: Check result == test_vectors[i].expected... ok
  test_strcmp.c:24: Check result == test_vectors[i].expected... ok
  SUCCESS: All conditions have passed.

Summary:
  Count of all unit tests:        1
  Count of run unit tests:        1
  Count of failed unit tests:     0
  Count of skipped unit tests:    0
SUCCESS: All unit tests have passed.


```
#### *****timeout 2 ./word-count/tokenize.bin ./word-count/txt/input.txt > ./word-count/out/input.txt.tokenize; diff  ./word-count/out/input.txt.tokenize ./word-count/reference/input.txt.tokenize*****
 ```
```
#### *****timeout 2 ./word-count/dictionary.bin ./word-count/txt/input.txt > ./word-count/out/input.txt.dictionary; diff  ./word-count/out/input.txt.dictionary ./word-count/reference/input.txt.dictionary*****
 ```
```
#### *****timeout 2 ./word-count/linecount.bin ./word-count/txt/input.txt > ./word-count/out/input.txt.linecount; diff  ./word-count/out/input.txt.linecount ./word-count/reference/input.txt.linecount*****
 ```
```
#### *****timeout 2 ./word-count/duplicate.bin  ./word-count/txt/input.txt ./word-count/txt/small.txt > ./word-count/out/input.txt.duplicate; diff  ./word-count/out/input.txt.duplicate ./word-count/reference/input.txt.duplicate*****
 ```
```
#### *****timeout 240 valgrind --leak-check=full ./word-count/tokenize.bin ./word-count/txt/input.txt*****
 ```==16583== Memcheck, a memory error detector
==16583== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==16583== Using Valgrind-3.15.0 and LibVEX; rerun with -h for copyright info
==16583== Command: ./word-count/tokenize.bin ./word-count/txt/input.txt
==16583== 
==16583== 
==16583== HEAP SUMMARY:
==16583==     in use at exit: 0 bytes in 0 blocks
==16583==   total heap usage: 383 allocs, 383 frees, 11,680 bytes allocated
==16583== 
==16583== All heap blocks were freed -- no leaks are possible
==16583== 
==16583== For lists of detected and suppressed errors, rerun with: -s
==16583== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)

```
#### *****timeout 240 valgrind --leak-check=full ./word-count/dictionary.bin ./word-count/txt/input.txt*****
 ```==16586== Memcheck, a memory error detector
==16586== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==16586== Using Valgrind-3.15.0 and LibVEX; rerun with -h for copyright info
==16586== Command: ./word-count/dictionary.bin ./word-count/txt/input.txt
==16586== 
==16586== 
==16586== HEAP SUMMARY:
==16586==     in use at exit: 0 bytes in 0 blocks
==16586==   total heap usage: 498 allocs, 498 frees, 13,893 bytes allocated
==16586== 
==16586== All heap blocks were freed -- no leaks are possible
==16586== 
==16586== For lists of detected and suppressed errors, rerun with: -s
==16586== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)

```
#### *****timeout 240 valgrind --leak-check=full ./word-count/linecount.bin ./word-count/txt/input.txt*****
 ```==16589== Memcheck, a memory error detector
==16589== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==16589== Using Valgrind-3.15.0 and LibVEX; rerun with -h for copyright info
==16589== Command: ./word-count/linecount.bin ./word-count/txt/input.txt
==16589== 
==16589== 
==16589== HEAP SUMMARY:
==16589==     in use at exit: 0 bytes in 0 blocks
==16589==   total heap usage: 594 allocs, 594 frees, 14,449 bytes allocated
==16589== 
==16589== All heap blocks were freed -- no leaks are possible
==16589== 
==16589== For lists of detected and suppressed errors, rerun with: -s
==16589== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)

```
#### *****timeout 240 valgrind --leak-check=full ./word-count/duplicate.bin  ./word-count/txt/input.txt ./word-count/txt/small.txt*****
 ```==16592== Memcheck, a memory error detector
==16592== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==16592== Using Valgrind-3.15.0 and LibVEX; rerun with -h for copyright info
==16592== Command: ./word-count/duplicate.bin ./word-count/txt/input.txt ./word-count/txt/small.txt
==16592== 
==16592== 
==16592== HEAP SUMMARY:
==16592==     in use at exit: 0 bytes in 0 blocks
==16592==   total heap usage: 643 allocs, 643 frees, 19,495 bytes allocated
==16592== 
==16592== All heap blocks were freed -- no leaks are possible
==16592== 
==16592== For lists of detected and suppressed errors, rerun with: -s
==16592== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)

```
