#ifndef MY_STRCMP_H
#define MY_STRCMP_H

int my_str_cmp(const char *s1, const char *s2);

#endif // !MY_STRCMP_H