## ********************FAILED********************

****************************************
## ********************SUCCESS********************
### *****timeout 120 java -jar venus.jar ./test_files/test_sdot.s > ./out/test_sdot.out*****
 ```
```
### *****diff ./out/test_sdot.out ./ref/test_sdot.out*****
 ```
```
