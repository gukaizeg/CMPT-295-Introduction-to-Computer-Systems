## ********************FAILED********************

****************************************
## ********************SUCCESS********************
#### *****make Relu.bin*****
 ```g++ -I./common -I./SoA -I./Relu -I./ReluEXT -I./Caxpy -I./Imax -DPREALLOCATE=1 -ggdb -ffast-math -fno-common -fno-builtin-printf -Wall -o Relu.bin ./Relu/main.cpp ./common/intrin.cpp ./common/logger.cpp -lm  

```
#### *****timeout 60 ./Relu.bin -l*****
 ```
[1;31mRELU [0m  
[1;31mRelu Serial [0m  
Results matched with answer!
Passed!!!
[1;31mRelu Vector [0m  
Results matched with answer!
***************** Printing Vector Unit Execution Log *****************
 Instruction | Vector Lane Occupancy ('*' for active, '_' for inactive)
------------- --------------------------------------------------------
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*___*_*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*_*__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*_*__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **_**_**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _***___*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **__****
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*__*__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _**__*__
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ***_____
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *****___
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _******_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_******
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ____**__
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*_***_*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*_**_*_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *___*_**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *___**__
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **_*___*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *__*___*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ********
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ___**__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **__*___
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ***___**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*_____
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ****____
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | __*_*_**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *___**__
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *__*_*__
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*___**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **_**__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *__*****
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ******__
      vstore | ********
****************** Printing Vector Unit Statistics *******************
Vector Width:              8
Total Vector Instructions: 224
Vector Utilization:        93.247768%
Utilized Vector Lanes:     1671
Total Vector Lanes:        1792
Passed!!!

```
#### *****make ReluEXT.bin*****
 ```g++ -I./common -I./SoA -I./Relu -I./ReluEXT -I./Caxpy -I./Imax -DPREALLOCATE=1 -ggdb -ffast-math -fno-common -fno-builtin-printf -Wall -o ReluEXT.bin ./ReluEXT/main.cpp ./common/intrin.cpp ./common/logger.cpp -lm  

```
#### *****timeout 60 ./ReluEXT.bin -l*****
 ```
[1;31mRELU [0m  
[1;31mRelu Serial [0m  
Results matched with answer!
Passed!!!
[1;31mRelu Vector [0m  
Results matched with answer!
***************** Printing Vector Unit Execution Log *****************
 Instruction | Vector Lane Occupancy ('*' for active, '_' for inactive)
------------- --------------------------------------------------------
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*_***_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _***__**
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*_**__*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _*______
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | **___*_*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_*_***_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *_**___*
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | _**_____
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | __**__*_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | ___*_***
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | __*__**_
      vstore | ********
       vload | ********
        vset | ********
         vlt | ********
     masknot | ********
        vset | ********
       vmove | *___**_*
      vstore | ********
       vload | ****____
        vset | ****____
         vlt | ****____
     masknot | ********
        vset | ****____
       vmove | ****__*_
      vstore | ****____
****************** Printing Vector Unit Statistics *******************
Vector Width:              8
Total Vector Instructions: 91
Vector Utilization:        89.697802%
Utilized Vector Lanes:     653
Total Vector Lanes:        728
Passed!!!

```
#### *****make Caxpy.bin*****
 ```g++ -I./common -I./SoA -I./Relu -I./ReluEXT -I./Caxpy -I./Imax -DPREALLOCATE=1 -ggdb -ffast-math -fno-common -fno-builtin-printf -Wall -o Caxpy.bin ./Caxpy/main.cpp ./common/intrin.cpp ./common/logger.cpp -lm  

```
#### *****timeout 60 ./Caxpy.bin -l*****
 ```
[1;31mCAXPY Serial [0m  
Results matched with answer!
Passed!!!
***************** Printing Vector Unit Execution Log *****************
 Instruction | Vector Lane Occupancy ('*' for active, '_' for inactive)
------------- --------------------------------------------------------
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | __*_**__
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | **_____*
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | ___**_**
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | _**_*___
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | _*__*___
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | *_*__*__
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | **__*_*_
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | _**_**_*
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | **__***_
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | *______*
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | __*____*
        vset | ********
       vload | ********
       vmult | ********
       vload | ********
        vadd | ********
       vload | ********
        vset | ********
         veq | ********
     masknot | ********
     maskand | ********
      vstore | ****_*_*
        vset | ****____
       vload | ****____
       vmult | ****____
       vload | ****____
        vadd | ****____
       vload | ****____
        vset | ****____
         veq | ****____
     masknot | ********
     maskand | ********
      vstore | *_*_____
****************** Printing Vector Unit Statistics *******************
Vector Width:              8
Total Vector Instructions: 143
Vector Utilization:        91.958042%
Utilized Vector Lanes:     1052
Total Vector Lanes:        1144
[1;31mCAXPY Vector [0m  
Results matched with answer!
Passed!!!

```
#### *****make SoA.bin*****
 ```g++ -I./common -I./SoA -I./Relu -I./ReluEXT -I./Caxpy -I./Imax -DPREALLOCATE=1 -ggdb -ffast-math -fno-common -fno-builtin-printf -Wall -o SoA.bin ./SoA/main.cpp ./common/intrin.cpp ./common/logger.cpp -lm  

```
#### *****timeout 60 ./SoA.bin -l*****
 ```
[1;31mARRAY SUM[0m (bonus) 
***************** Printing Vector Unit Execution Log *****************
 Instruction | Vector Lane Occupancy ('*' for active, '_' for inactive)
------------- --------------------------------------------------------
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
       vload | ********
      vstore | ********
****************** Printing Vector Unit Statistics *******************
Vector Width:              8
Total Vector Instructions: 24
Vector Utilization:        100.000000%
Utilized Vector Lanes:     192
Total Vector Lanes:        192
Passed!!!

```
#### *****make Imax.bin*****
 ```g++ -I./common -I./SoA -I./Relu -I./ReluEXT -I./Caxpy -I./Imax -DPREALLOCATE=1 -ggdb -ffast-math -fno-common -fno-builtin-printf -Wall -o Imax.bin ./Imax/main.cpp ./common/intrin.cpp ./common/logger.cpp -lm  

```
#### *****timeout 60 ./Imax.bin -l*****
 ```
[1;31mIMAX [0m  
[1;31mIMAX Serial [0m  
Results matched with answer!
Passed!!!
[1;31mIMAX Vector [0m  
Results matched with answer!
***************** Printing Vector Unit Execution Log *****************
 Instruction | Vector Lane Occupancy ('*' for active, '_' for inactive)
------------- --------------------------------------------------------
       vload | ********
        vset | ********
         vgt | _*___*_*
     cntbits | ********
        vset | ********
         vgt | _____*__
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ____*__*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ___**___
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _***___*
     cntbits | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _*___**_
     cntbits | ********
        vset | ********
         vgt | _____*__
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _**_**_*
     cntbits | ********
        vset | ********
         vgt | ____*__*
     cntbits | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _**_***_
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _*******
     cntbits | ********
        vset | ********
         vgt | ___*____
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ___****_
     cntbits | ********
        vset | ********
         vgt | _____**_
     cntbits | ********
        vset | ********
         vgt | ______*_
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ____**__
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _*******
     cntbits | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _****_**
     cntbits | ********
        vset | ********
         vgt | ____*_*_
     cntbits | ********
        vset | ********
         vgt | ______*_
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ______**
     cntbits | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ___**___
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ___**__*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ____*___
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _**___*_
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | __*_____
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | __*_****
     cntbits | ********
        vset | ********
         vgt | ____*_**
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _____*__
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ___*____
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | __*___**
     cntbits | ********
        vset | ********
         vgt | _______*
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ____*___
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | ________
     cntbits | ********
       vload | ********
        vset | ********
         vgt | _**__*__
     cntbits | ********
        vset | ********
         vgt | ________
     cntbits | ********
****************** Printing Vector Unit Statistics *******************
Vector Width:              8
Total Vector Instructions: 251
Vector Utilization:        75.796813%
Utilized Vector Lanes:     1522
Total Vector Lanes:        2008
Passed!!!

```
